CREATE TRIGGER occupation_permission_mapping_BEFORE_UPDATE
BEFORE UPDATE ON occupation_permission_mapping
FOR EACH ROW
  BEGIN
	set NEW.modify_date_time = CURRENT_TIMESTAMP;
END;
