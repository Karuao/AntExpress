CREATE TRIGGER identifying_code_BEFORE_UPDATE
BEFORE UPDATE ON identifying_code
FOR EACH ROW
  BEGIN
	set NEW.modify_date_time = CURRENT_TIMESTAMP;
END;
