CREATE TRIGGER express_delivery_bill_BEFORE_UPDATE
BEFORE UPDATE ON express_delivery_bill
FOR EACH ROW
  BEGIN
	set NEW.modify_date_time = CURRENT_TIMESTAMP;
END;
